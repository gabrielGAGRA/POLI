package strategy;

private<T extends Comparable<T>>void quickSort(T[]array,int i,int j,int order){ // Changed SortOrder to int
if(i>=j){return;}int pivotIndex=partition(array,i,j,order);quickSort(array,i,pivotIndex-1,order);quickSort(array,pivotIndex+1,j,order);}

private<T extends Comparable<T>>int partition(T[]array,int start,int end,int order){ // Changed SortOrder to int
T pivot=array[end];int balancePoint=start;

for(int i=start;i<end;i++){boolean shouldSwap;if(order==SortContext.ASCENDING){ // Used SortContext.ASCENDING
shouldSwap=array[i].compareTo(pivot)<=0;}else{ // DESCENDING (order == SortContext.DESCENDING)
shouldSwap=array[i].compareTo(pivot)>=0;}

if(shouldSwap){T tmp=array[i];array[i]=array[balancePoint];array[balancePoint]=tmp;balancePoint++;}}

T tmp=array[end];array[end]=array[balancePoint];array[balancePoint]=tmp;

return balancePoint;}